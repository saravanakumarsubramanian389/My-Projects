# Importing all the necessary libraries to run the model
import pandas as pd
import numpy as np
import math
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import skew
import warnings
from sklearn import preprocessing
from sklearn.metrics import classification_report
from sklearn.preprocessing import LabelEncoder , OneHotEncoder
import joblib
import os
cpath = os.path.abspath(os.getcwd())
from imblearn.over_sampling import SMOTE
import sklearn.model_selection as ms
from sklearn.model_selection import cross_validate
from sklearn.decomposition import PCA
import sklearn.decomposition as skde
from sklearn.metrics import classification_report, accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB, BernoulliNB, MultinomialNB
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.ensemble import ExtraTreesClassifier
from xgboost import XGBClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.datasets import make_classification
from sklearn.model_selection import cross_val_score
from numpy import mean
from numpy import std
warnings.filterwarnings("ignore")

#Execution controls

read=1
primary_analysis=0 #apply to find the skewness, unique values and missing value in the datadet
visual=0
observed_corrections=1
define_variables=1
feature_importance=0 #apply to find theimportance of feature independently with the dependent variable
analyze_stats=0; #apply to find the correlation between the features
feature_engineering=1
scaling=1
encoding=1
matrix_corrections=1
reduce_dim=0
cross_validate=1   ; #apply to cross validate the model using K-Fold analysis
train_classification=1

##Importing the datafile from the saved filepath
if read==1:
    filepath = "data/project/corporate_rating.csv"
    y_name = 'Rating'
    df = pd.read_csv(filepath)
    y_count = df.Rating.value_counts()
    # print(y_count)
    rating_dict = {'AAA':'Low_Risk', 
                'AA':'Low_Risk',
                'A':'Low_Risk',
                'BBB':'Medium_Risk', 
                'BB':'High_Risk',
                'B':'High_Risk',
                'CCC':'Very_High_Risk', 
                'CC':'Very_High_Risk',
                'C':'Very_High_Risk',
                'D':'Very_High_Risk'}

    # Sector = {'Basic Industries':'Sector_3','Capital Goods':'Sector_3',
    #           'Consumer Durables':'CD','Consumer Non-Durables':'Sector_1',
    #           'Consumer Services':'Sector_3','Energy':'Sector_3','Finance':'Fin',
    #           'Health Care':'HC','Miscellaneous':'Sector_1','Public Utilities':'Sector_3',
    #           'Technology':'Sector_3','Transportation':'Sector_4'}

    df.Rating = df.Rating.map(rating_dict)
    # df.Sector = df.Sector.map(Sector)
    ax = df['Rating'].value_counts().plot(kind='bar',figsize=(8,4),title="Count of Rating by Type",grid=True)
    cx=df.Rating.value_counts()
    print(cx)

def outlier_treatment(df):
    outlier_dict = {}
    for col in df.select_dtypes(exclude = 'O').columns:     
        Q1 = np.percentile(df[col], 25, interpolation = 'midpoint')
        Q2 = np.percentile(df[col], 50, interpolation = 'midpoint')  
        Q3 = np.percentile(df[col], 75, interpolation = 'midpoint')
        
        IQR = Q3 - Q1
        # print('Interquartile range is', IQR)
        
        low_lim = Q1 - 1.5 * IQR
        up_lim = Q3 + 1.5 * IQR
        
        # print('low_limit is', low_lim)
        # print('up_limit is', up_lim)
        
        outlier_dict[col] = []
        for x in df[col]:
            if ((x> up_lim) or (x<low_lim)):
                 outlier_dict[col].append(x)
        # print(' outlier in the dataset is', outlier_dict[col])
    return outlier_dict


##Extracting the data to understand the datatype, outliers in the data and check the missing value of each feature

if primary_analysis==1:
    skew_check = df.skew()
    print(skew_check)
    df_h = df.head()
    outlier = outlier_treatment(df)

    with open("capstoneproject_dtype_analysis.txt", "w") as f:
        for c in df_h:
            line1 = df_h[c]
            line2 = df[c].nunique()
            line3 = df[c].isnull().sum()
            f.write(str(line1) + "\n" + "Unique: " + str(line2) + 
                    ", missing: " + str(line3)
            + "\n\n" + "-----------------"+"\n")

# No Missing value is found but almost all features as outliers due to 12 different sector is segregated in the same dataset
        
#To Check the correlation among the features in the dataset    
if analyze_stats==1:
    corr=df.corr()
    mask = np.triu(np.ones_like(corr, dtype=np.bool))
    fig, ax = plt.subplots(figsize=(20, 20))
    sns.heatmap(corr, mask = mask, annot=True)



if observed_corrections==1:
    print("The shape of model is ", df.shape)
    ##The date and Name does not have an impact on the risk prediction in this data set and hence we remove the date and the name to reduce the dimension during the OHE
    df = df.drop(['Name','Date'], axis=1)
    #Based on the correlation check we have removed all the below features which has more than 90% multicollinearity with another feature
    df = df.drop(['pretaxProfitMargin','netProfitMargin','operatingProfitMargin','returnOnCapitalEmployed',
                  'returnOnEquity','fixedAssetTurnover','cashPerShare','operatingCashFlowPerShare'], axis=1)
    print("The shape of model after removing the multicollinearity and unwanted feature is ", df.shape)
    print(df.head())
    pass

##Creating functions like converting the data into dataframe,
##segragating the numerical and categorical feature seprately, and later joining the same with a  concatenate function
def data_to_df(x):
    if not isinstance(x, pd.DataFrame):
        x = pd.DataFrame(x)
    return x

def split_num_cat(X):
    x_num = X.select_dtypes(exclude=['O'])
    x_cat = X.select_dtypes(include=['O'])
    return x_num, x_cat


def join_num_cat(x_num, x_cat):
    X = np.concatenate((x_num,x_cat),axis=1)
    X = pd.DataFrame(X)
    return X

##Defining the features and the dependent variable      


if define_variables==1:
    y = df[y_name]
    x = df.drop([y_name],axis=1); #print(x.info())
    x_num, x_cat = split_num_cat(x)
    x_num = np.exp(x_num)
    x_num=pd.DataFrame(x_num)
    print(x_num)
    n_dim = x.shape[1]
    print(x.shape)


#Visualising the skewness of the numerical features using a distribution plot 

if visual==1:
    x_num, x_cat = split_num_cat(x)
    for col in x_num:
        print(col)
        print(skew(df[col]))
        plt.figure()
        sns.distplot(df[col])
        plt.show()
        
   
    def plot_violin(df, cols, col_x = 'Rating'):
        for col in cols:
            sns.set_style("whitegrid")
            sns.violinplot(col_x, col, data=df)
            plt.xlabel(col_x) # Set text for the x axis
            plt.ylabel(col)# Set text for y axis
            plt.show()
            
    plot_violin(df, x_num)
    plt.show()
            
    x = join_num_cat(x_num,x_cat)


# Using the feature importance technique to find the feature importance of the model

if feature_importance == 1:
    x_num, x_cat = split_num_cat(x)
    model = ExtraTreesClassifier()
    model.fit(x_num,y)
    print(model.feature_importances_) #use inbuilt class feature_importances of tree based classifiers
    #plot graph of feature importances for better visualization
    feat_importances = pd.Series(model.feature_importances_, index=x_num.columns)
    feat_importances.nlargest(10).plot(kind='barh')
    plt.show()
    X = join_num_cat(x_num,x_cat)
    x = pd.DataFrame(X)

##Creating the label encoder and one-hot encoding function to convert the categorical data from the dataframe to ordinal 
LE = LabelEncoder()
OHE = OneHotEncoder(handle_unknown='ignore')


def label_encode(X):
    try:
        d = X.shape[1]
        for col in X.columns:
            labels = LE.fit_transform(X[col].values)
            X[col] = labels.astype(str)
    except:
        X = LE.fit_transform(X.values)
        
    return X


def onehot_encode(X_cat):
    print(X_cat.shape)
    X_cat_le = X_cat.apply(lambda col: LE.fit_transform(col)); #print(S)
    OHE_model = OHE.fit(X_cat_le)
    joblib.dump(OHE_model,cpath+"/models/ohe_model.pkl")
    X_cat_ohe = OHE.transform(X_cat_le).toarray();  #print(2,F.shape, F[0])
    return X_cat_ohe

#Since we have few cateforical features in the data we need to label encode and OHE it.
if encoding==1:
    x_num, x_cat = split_num_cat(x)
    
    if True:
        x_cat = label_encode(x_cat)
        for col in x_cat.columns:
            x_cat[col] = x_cat[col].astype(float)
    
        
    if True:
        x_cat = onehot_encode(x_cat)
        
    x = join_num_cat(x_num,x_cat)         
    print(x.shape)

    
if feature_engineering==1:
   # #subjective and optional - True enables the execution
   x_num, x_cat = split_num_cat(x)
        
   print("Initial feature:");print(x.head(1));print("")
   
   x_num['nf1'] = x_num.mean(axis=1)
   x_num['nf2'] = x_num.std(axis=1)
   print(x_num.head(1));print("")
   
   x = join_num_cat(x_num,x_cat)
   pass

def minmax_normalization(X):
    scaler = preprocessing.MinMaxScaler().fit(X)
    X = scaler.transform(X)
    joblib.dump(scaler,cpath+"/models/norm_scaler.pkl")
    return X    
  

if scaling==1:
    x_num, x_cat = split_num_cat(x)
    
    if True:
        # x_num, fm = max_normalization(x_num)
        x_num = minmax_normalization(x_num) 
    
    x = join_num_cat(x_num,x_cat)


def matrix_correction(x):
    x = pd.DataFrame(x)
    for c in x.columns:
        x[c] = x[c].replace(to_replace=np.nan, value=0)
        x[c] = x[c].replace(to_replace=np.inf, value=sorted(list(x[c]),reverse=True)[1])
        x[c] = x[c].replace(to_replace=-np.inf, value=sorted(list(x[c]),reverse=True)[-2])
    return x.values
      
if matrix_corrections==1:   
    x = matrix_correction(x)


pca = PCA(0.95).fit(x)
n_dim = pca.n_components_
print("The dimensions has been reduced to :" , n_dim)
    
def reduce_dimensions(X, n_dim):
    pca_model = skde.PCA(n_components=n_dim)
    pca_fit = pca_model.fit(X)
    X = pca_fit.transform(X)
    print("PCA variance:")
    # print(pca_fit.explained_variance_ratio_); print("")
    joblib.dump(pca_fit, cpath+"/models/pca_model.pkl")
    return X

if reduce_dim==1:
    x = reduce_dimensions(x,n_dim); print(x.shape)
    print("transformed x:")
    print(x.shape); print("")
    

def get_models():
    models = {}
    models['LogR'] = LogisticRegression()
    models['KNN'] = KNeighborsClassifier()
    models['DTC'] = DecisionTreeClassifier()
    models['NBC'] = MultinomialNB()
    models['SVC'] = SVC()
    # models['GBC'] = GradientBoostingClassifier()
    # models['XGB'] = XGBClassifier()
    # models['MLP'] = MLPClassifier()
    return models

def kfold_cross_validate(model,X,Y,rstate):
    feature_folds = ms.KFold(n_splits=5, shuffle = True, random_state=rstate)
    cv_estimate = ms.cross_val_score(model, X, Y, cv = feature_folds)
    print('Mean performance metric = ', np.mean(cv_estimate))
    print('SDT of the metric       = ', np.std(cv_estimate))
    print('Outcomes by cv fold')
    for i, x in enumerate(cv_estimate):
        print('Fold ', (i+1, x))
    print("")
    
    
if cross_validate==1:
    best_model = SVC(C=10, class_weight='balanced', kernel='poly', random_state=114)
    kfold_cross_validate(best_model, x, y,114)

 
def threshold_prediction(model, x_test, y, pred_th=0.60):
    test_pred_prob = model.predict_proba(x_test); #print(test_pred_prob[0], test_pred[0])
    test_pred = []
    for p in test_pred_prob:
        th_met = 0
        for v in sorted(list(y.value_counts().index)):
            if p[v]>pred_th:
                test_pred.append(v)
                th_met=1
                break
        if th_met==0:
            test_pred.append(-1)
    test_pred = np.array(test_pred)
    return test_pred

def clf_train_test(model, x, y, rstate, model_id,pred_th=None):
    print(model); print("")
    x_train,x_test,y_train,y_test=ms.train_test_split(x,y,test_size=0.30, random_state=rstate)
    x_train,y_train = SMOTE().fit_resample(x_train,y_train)
    model_fit = model.fit(x_train,y_train)
    joblib.dump(model_fit, cpath+"/models/model_"+str(model_id))
    train_pred = model_fit.predict(x_train)


    print(x.shape); print(y.value_counts())
    
    if pred_th != None:
        test_pred = threshold_prediction(model_fit, x_test, y, pred_th)
    else:
        test_pred = model_fit.predict(x_test)
       
    print("Training:")
    print(classification_report(y_train, train_pred))
#    print("roc_auc:", roc_auc_score(y_train, train_pred))
    print("")
    print("% of Unknown classe @ threshold = "+str(pred_th), " is ", round(len(test_pred[test_pred==-1])/len(test_pred),3))
    print("Testing:")
    print(classification_report(y_test, test_pred))
   # print("roc_auc:", roc_auc_score(y_test, test_pred))
    return model_fit

if train_classification==1:
    best_param_model = SVC(C=10, class_weight='balanced', kernel='poly', random_state=114)
    # best_param_model = KNeighborsClassifier()
    # best_param_model = XGBClassifier(random_state = 116, class_weight = 'balanced')
    # best_param_model = GradientBoostingClassifier(random_state = 111,n_estimators = 250,learning_rate = 0.01,subsample=0.90)
    # best_param_model = RandomForestClassifier(random_state = 116)
    # best_param_model = DecisionTreeClassifier(random_state = 116) 
    # best_param_model = MultinomialNB()
    clf_train_test(best_param_model,x,y,116,"SVM")
  

    